//import { Link } from "react-router-dom";
import PageContent from "../components/PageContent";

export default function HomePage() {
  return (
    <>
      <PageContent title="Welcome">
        <p>Browse all our amazing events!</p>
      </PageContent>
      {/* <button>
        <Link to="events">All Events</Link>
      </button>

      <button>
        <Link to="newevent">New Event</Link>
      </button>*/}
    </>
  );
}
