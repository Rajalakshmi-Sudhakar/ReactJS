import EventForm from "../components/EventForm";

export default function NewEventPage() {
  return <EventForm method="post" />;
}
